//
//  ViewController4Part2.swift
//  lab1
//
//  Created by bob on 06/06/1401 AP.
//

import UIKit

class ViewController4Part2: UIViewController {
    @IBOutlet weak var judge: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var RESULT: UILabel!
    @IBOutlet weak var hslider: UISlider!
    @IBOutlet weak var hnumber: UILabel!
    @IBAction func Height_slider(_ sender: Any) {
        hslider.minimumValue = Float (0.000000)
        hslider.maximumValue = Float (300.000000)
        hnumber.text  = "\(hslider.value)"
        
        self.sendHvalue()
    }
    @IBOutlet weak var wslider: UISlider!
    @IBOutlet weak var wnumber: UILabel!
    @IBAction func Weight_slider(_ sender: Any) {
        wslider.minimumValue = Float(0.000000)
        wslider.maximumValue = Float(300.000000)
        wnumber.text = "\(wslider.value)"
        self.sendHvalue()
        
    }
    func sendHvalue(){
        let hvalue = Float(hslider.value)
        let wvalue = Float(wslider.value)
        let sqre = hvalue * hvalue
        let ans = wvalue / sqre * 703
        RESULT.text = "\(ans)"
        if(ans<18){
            self.judge.textColor = UIColor.blue
            judge.text = "You are very thin"
        }
        else if(ans>=18&&ans<25){
            self.judge.textColor = UIColor.green
            judge.text = "average size"
            
        }
        else if(ans>=25&&ans<30){
            self.judge.textColor = UIColor.purple
            judge.text = "large size"
            
        }
        else{
            self.judge.textColor = UIColor.red
            judge.text = "are U Hulk?"
            
        }
        
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
