//
//  PART2VIEWCONTROLLER.swift
//  lab1
//
//  Created by bob on 05/06/1401 AP.
//

import UIKit


class PART2VIEWCONTROLLER: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var Hnumber: UILabel!
    @IBAction func Height(_ sender: Any) {
        Hnumber.text = "\(slider1.value)"
    }
    
    
    
    
    
    
    
    
    
    override func setValue(_ value: Any?, forUndefinedKey key: String){
       }
    
}
    
    
/*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


