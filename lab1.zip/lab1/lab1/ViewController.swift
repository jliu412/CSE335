//
//  ViewController.swift
//  lab1
//
//  Created by bob on 05/06/1401 AP.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

