//
//  PART1VIEWCONTROLLERViewController.swift
//  lab1
//
//  Created by bob on 05/06/1401 AP.
//

import UIKit

class PART1VIEWCONTROLLERViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var Weight: UITextField!
    @IBOutlet weak var Height: UITextField!
    @IBOutlet weak var MBInumber: UILabel!
    @IBOutlet weak var judge: UILabel!
    
    @IBAction func cal(_ sender: Any)
    {
        let weight = self.Weight.text ?? "0"
        let height = self.Height.text ?? "0"
        
        var heightSQ = Float(height)! * Float(height)!
        
        let result = Float(weight)! / Float(exactly: heightSQ)! * 730
        MBInumber.text = String(result)
        
        if(result<18)
        {
            self.judge.textColor = UIColor.blue
            judge.text = "You are very thin"
        }
        else if(result>=18 && result<25)
        {
            self.judge.textColor = UIColor.green
            judge.text = "average size"
            
        }
        else if(result>=25 && result<30)
        {
            self.judge.textColor = UIColor.purple
            judge.text = "large size"
            
        }
        else
        {
            self.judge.textColor = UIColor.red
            judge.text = "are U Hulk?"
            
        }
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


