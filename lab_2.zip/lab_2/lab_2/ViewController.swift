//
//  ViewController.swift
//  lab_2
//
//  Created by bob on 15/06/1401 AP.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {
    var info = ""
    @IBOutlet weak var weight_earth: UITextField!
    @IBOutlet weak var infor: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        infor.text = info
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let des = segue.destination as!
        tomoonViewController
        if(segue.identifier == "toMoon")
        {
            des.fromEarth = "come from Earth!"
            des.wEarth = Double(self.weight_earth.text ?? "0") ?? 0.0
            des.wMoon = des.wEarth / 6
            des.inf = "i feel much lighter!"
        }
        
    }
    
    @IBAction func fromMoon(segue:UIStoryboardSegue)
    {
        
        
    }
    
    @IBAction func toEarth( _ segue: UIStoryboardSegue) {
        
        if segue.source is tomoonViewController
        {
            info = "back from moon!"
            infor.text = info
        }
        
        else
        {
            info = "back from jupiter!"
            infor.text = info        }
        
    }
    
    @IBAction func fromJupiter(segue:UIStoryboardSegue)
    {
        
        
    }
}




