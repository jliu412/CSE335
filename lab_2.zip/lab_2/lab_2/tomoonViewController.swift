//
//  tomoonViewController.swift
//  lab_2
//
//  Created by bob on 15/06/1401 AP.
//

import UIKit

class tomoonViewController: UIViewController {
   
    var wEarth = 0.00
    var wMoon = 0.00
    var inf = " "
    @IBOutlet weak var wNUM_Earth: UILabel!
    @IBOutlet weak var wNUM_Moon: UILabel!
    @IBOutlet weak var inforn: UILabel!
    @IBOutlet weak var comefrom: UILabel!
    var fromEarth:String?
    var data:Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        wNUM_Earth.text = String(wEarth)
        wNUM_Moon.text = String(wMoon)
        inforn.text = inf
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if(segue.identifier == "toJupiter")
        {
            let des = segue.destination as! jupiterViewController
            des.frommoon = "come from Moon!"
            des.mEarth = Double(self.wNUM_Earth.text ?? "0") ?? 0
            des.mJupiter = des.mEarth * 2.4
            des.infomation = "i feel much heavier!"
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

    @IBAction func toMoon( _ seg: UIStoryboardSegue) {
    
    
    }
    
    func Moon(segue:UIStoryboardSegue)
    {
        
        if let sourceViewController = segue.source as? tomoonViewController
        {
            comefrom.text = "come from moon"
        }
        else if let sourceViewController = segue.source as? jupiterViewController
        {
            comefrom.text = "come from jupiter"
        }
        /*else if let sourceViewController = segue.source as?
        //{
        //}*/
            
            }        // Do any additional setup after loading the view.
    
}
