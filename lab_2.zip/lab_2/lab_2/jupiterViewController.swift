//
//  jupiterViewController.swift
//  lab_2
//
//  Created by bob on 15/06/1401 AP.
//

import UIKit

class jupiterViewController: UIViewController {
    @IBOutlet weak var earth_num_ju: UILabel!
    @IBOutlet weak var jupiter_num: UILabel!
    @IBOutlet weak var inf: UILabel!
    @IBOutlet weak var comefrom2: UILabel!
    var mEarth = 0.0
    var mJupiter = 0.0
    var infomation = " "
    var frommoon:String?
    var Jdata:Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        earth_num_ju.text = String(mEarth)
        jupiter_num.text = String(mJupiter)
        inf.text = infomation
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    

}
