//
//  ViewModel.swift
//  L5
//
//  Created by X on 2022/10/10.
//

import Foundation
import CoreData
import SwiftUI
import PhotosUI



class ViewModel: ObservableObject {
    
    @Published var name: String = ""
    @Published var des: String = ""
    @Published var pic: Data? = nil
    @Published var selectedItem: PhotosPickerItem? = nil
    
    func addItem(viewContext: NSManagedObjectContext) {
        let city = City(context: viewContext)
        city.cPic = UIImage(named: String(Int.random(in: 1...6)))?.jpegData(compressionQuality: 1)
        city.cName = name
        city.cDes = des
        do {
            try viewContext.save()
        } catch {}
    }
    
    func deleteItems(viewContext: NSManagedObjectContext) {
        let request: NSFetchRequest<City> = City.fetchRequest()
        request.entity = NSEntityDescription.entity(forEntityName: "City", in: viewContext)
        request.predicate = NSPredicate(format: "(cName = %@)", name)
        do {
            let results = try viewContext.fetch(request as! NSFetchRequest<NSFetchRequestResult>)
            if results.count > 0 {
                viewContext.delete(results[0] as! NSManagedObject)
                do {
                    try viewContext.save()
                } catch {}
            }
        } catch {}
    }
}

