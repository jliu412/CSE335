//
//  L5App.swift
//  L5
//
//  Created by 刘晋好 on 10/10/22.
//

import SwiftUI

@main
struct L5App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
