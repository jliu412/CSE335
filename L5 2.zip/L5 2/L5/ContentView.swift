//
//  ContentView.swift
//  L5
//
//  Created by 刘晋好 on 10/10/22.
//

import SwiftUI
import CoreData
import PhotosUI

struct ContentView: View {
    
    @ObservedObject var vm: ViewModel = ViewModel()
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \City.cName, ascending: true)],
        animation: .default)
    
    private var cities: FetchedResults<City>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    TextField("Name(input name and click del can delet)", text: $vm.name).textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Des", text: $vm.des).textFieldStyle(RoundedBorderTextFieldStyle())
                    Button{
                        vm.addItem(viewContext: viewContext)
                    } label: {
                        Text("add")
                    }
                    Button{
                        vm.deleteItems(viewContext: viewContext)
                    } label: {
                        Text("del")
                    }
                }.padding()
                List {
                    ForEach(cities) { city in
                        NavigationLink {
                            
                            PhotosPicker(
                                selection: $vm.selectedItem,
                                matching: .images,
                                photoLibrary: .shared()) {
                                    VStack {
                                        Text("(click photo to switch)")
                                        Image(uiImage: UIImage(data: (vm.pic ?? UIImage(named: String(Int.random(in: 1...6)))?.jpegData(compressionQuality: 1)!)!)!)
                                            .resizable()
                                            .scaledToFit()
                                        Text(city.cName!).font(.largeTitle)
                                        Text(city.cDes!)
                                    }
                                }.onChange(of: vm.selectedItem) { newItem in
                                    Task {
                                        if let data = try? await newItem?.loadTransferable(type: Data.self) {
                                            vm.pic = data
                                        }
                                    }
                                }
                        } label: {
                            Text(city.cName!)
                        }
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
